
public interface IDamageable {
    void TakeDamage();
}
